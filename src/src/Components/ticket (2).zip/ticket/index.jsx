import { useState, useEffect } from "react";
import axios from "axios";
import TicketCount from "./ticketComponents/TicketCount";
import TicketSearch from "./ticketComponents/TicketSearch";
import TicketTable from "./ticketComponents/TicketsTable";
import AddTicketModal from "./ticketComponents/AddTiicketModal";
import AddIcon from "@mui/icons-material/Add";
import {  useAuth } from "../Context/AuthContext";
const Tickets = () => {
  const [tickets, setTickets] = useState([]); // Initialize as empty array
  const [filteredTickets, setFilteredTickets] = useState([]); // Initialize as empty array
  const [isModalOpen, setIsModalOpen] = useState(false); // Manage modal visibility
  const [loading, setLoading] = useState(true); // Manage loading state
  const [error, setError] = useState(null); // Manage error state
  const {authState}=useAuth()
  console.log(authState)
  // Fetch tickets from the API on component mount
  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const response = await axios.get("http://localhost:8080/findAllTicket");
        console.log(response.data.data)
        setTickets(response.data.data); // Set tickets data from API
        setFilteredTickets(response.data.data); // Set the filtered tickets to the same initially
        setLoading(false); // Set loading to false once data is fetched
      } catch (err) {
        console.error("Error fetching tickets:", err);
        setError("Failed to load tickets");
        setLoading(false); // Set loading to false if an error occurs
      }
    };

    fetchTickets();
  }, []);

  // Handle search functionality
  const handleSearch = (filtered) => {
    setFilteredTickets(filtered);
  };

  if (loading) {
    return <div>Loading...</div>; // Show loading message while data is being fetched
  }

  if (error) {
    return <div>{error}</div>; // Show error message if an error occurs while fetching data
  }

  return (
    <>
    
      <div className="page-header mb-6">
        <div className="flex flex-wrap items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold">Tickets</h3>
            <ul className="flex items-center space-x-2 text-sm text-gray-500">
              <li>
                <a href="/admin-dashboard" className="hover:text-blue-600">
                  Dashboard
                </a>
              </li>
              <li>/</li>
              <li className="text-gray-800">Tickets</li>
            </ul>
          </div>
          <div>
            <button
              className="font-medium py-2 px-4 sm:px-6 bg-[#b17f27] text-white rounded-full flex justify-center items-center gap-2 h-[40px] text-sm sm:text-base hover:bg-[#a56f23] transition-all duration-200 w-full sm:w-auto w-[175px] sm:flex-wrap"
              onClick={() => setIsModalOpen(true)} // Open modal
            >
              <AddIcon />
              <span>Add Ticket</span>
            </button>
          </div>
        </div>
      </div>
      {authState.role==="admin" && (
        <div className="mb-6">
        <TicketCount tickets={tickets} />
      </div>
      )}
      
      <div className="mb-6">
        <TicketSearch tickets={tickets} onSearch={handleSearch} />
      </div>
      <div>
        <TicketTable tickets={filteredTickets} />
      </div>
      <AddTicketModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />{" "}
      {/* Modal component */}
    </>
  );
};

export default Tickets;
