import { useState, useEffect } from "react";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Avatar,
  Typography,
  FormControl,
  Select,
  MenuItem,
  Menu,
  IconButton,
  Modal,
  Box,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import EditTicketForm from "./EditTicketModel";  // Correct component import
import axios from "axios";
import { Margin } from "@mui/icons-material";

const TicketTable = ({ tickets }) => {
  const [ticketData, setTicketData] = useState(tickets);
  const [anchorEl, setAnchorEl] = useState(null);  // State to manage the menu anchor
  const [selectedTicket, setSelectedTicket] = useState(null);  // To store selected ticket for actions
  const [openEditModal, setOpenEditModal] = useState(false);
  const navigate = useNavigate();

  // Effect to update ticketData when tickets prop changes
  useEffect(() => {
    setTicketData(tickets);
  }, [tickets]);

  const handlePriorityChange = (id, newPriority) => {
    setTicketData((prevTickets) =>
      prevTickets.map((ticket) =>
        ticket.id === id ? { ...ticket, priority: newPriority } : ticket
      )
    );
  };

  const handleStatusChange = (id, newStatus) => {
    setTicketData((prevTickets) =>
      prevTickets.map((ticket) =>
        ticket.id === id ? { ...ticket, status: newStatus } : ticket
      )
    );
  };

  const handleRowClick = (id, ticket) => {
    localStorage.setItem('selectedTicket', JSON.stringify(ticket));
    navigate(`/ticket/${id}`);
  };

  const handleClickMenu = (event, ticket) => {
    setAnchorEl(event.currentTarget);
    setSelectedTicket(ticket); // Set selected ticket for Edit/Delete actions
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  const handleDelete = async (ticketId) => {
    try {
      // Send DELETE request to the backend to delete the ticket
      const response = await axios.delete(
        `https://localhost:8080/tickets/${ticketId}`  // Replace with your actual API URL
      );
  
      // If successful, filter the ticket out of the local state
      setTicketData((prevTickets) =>
        prevTickets.filter((ticket) => ticket.id !== ticketId)
      );
  
      console.log('Ticket deleted successfully', response.data);  // Optional: Log the response or show a success message
      handleCloseMenu();  // Close the menu after the deletion
    } catch (error) {
      console.error('Error deleting ticket:', error);
      // Optional: Handle errors, such as showing an error message to the user
    }
  };
  

  const handleOpenEditModal = () => {
    setOpenEditModal(true);  // Open the modal for editing
  };

  const handleCloseEditModal = () => {
    setSelectedTicket(null);  // Clear selected ticket on modal close
    setOpenEditModal(false);  // Close the edit modal
    handleCloseMenu();  // Close the menu as well when modal is closed
  };

  const handleSaveTicket = async (updatedTicket) => {
    try {
      // Send PUT request to update the ticket on the backend
      const response = await axios.put(
        `https://localhost:8080/tickets/${selectedTicket.id}`,  // Replace with your actual API URL
        updatedTicket
      );

      // Update the local state if the request is successful
      setTicketData((prevTickets) =>
        prevTickets.map((ticket) =>
          ticket.id === selectedTicket.id ? { ...ticket, ...updatedTicket } : ticket
        )
      );

      console.log('Ticket updated successfully', response.data);  // You can log the response or show a success message

      // Close the modal after saving the ticket
      handleCloseEditModal();
    } catch (error) {
      console.error('Error updating ticket:', error);
      // You can handle errors here, such as showing an error message
    }
  };

  // Helper function to determine priority color
  const getPriorityColor = (priority) => {
    switch (priority) {
      case "High":
        return "red";
      case "Medium":
        return "orange";
      case "Low":
        return "green";
      default:
        return "black";
    }
  };

  // Helper function to determine status color
  const getStatusColor = (status) => {
    switch (status) {
      case "New":
        return "blue";
      case "Open":
        return "yellow";
      case "Pending":
        return "orange";
      case "Closed":
        return "green";
      default:
        return "black";
    }
  };

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>#</TableCell>
            <TableCell>Ticket ID</TableCell>
            <TableCell>Subject</TableCell>
            <TableCell>Assigned Staff</TableCell>
            <TableCell>Created Date</TableCell>
            <TableCell>Priority</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {ticketData.map((ticket) => (
            <TableRow key={ticket.id}>
              <TableCell onClick={() => handleRowClick(ticket.id,ticket)}>{ticket.id}</TableCell>
              <TableCell onClick={() => handleRowClick(ticket.id,ticket)}>{ticket.ticketId}</TableCell>
              <TableCell>{ticket.subject}</TableCell>
              <TableCell>
                <div style={{ display: "flex", alignItems: "center" }}>
                  <Avatar sx={{ margin:2}} src={ticket.staff || "/default-avatar.jpg"} />
                  <Typography>{ticket.employeeName || "Unknown"}</Typography>
                </div>
              </TableCell>
              <TableCell>{ticket.date}</TableCell>
              <TableCell>
                <FormControl size="small" fullWidth>
                  <Select
                    value={ticket.priority}
                    onChange={(e) => handlePriorityChange(ticket.id, e.target.value)}
                    style={{ color: getPriorityColor(ticket.priority) }}
                  >
                    <MenuItem value="High" style={{ color: "red" }}>High</MenuItem>
                    <MenuItem value="Medium" style={{ color: "orange" }}>Medium</MenuItem>
                    <MenuItem value="Low" style={{ color: "green" }}>Low</MenuItem>
                  </Select>
                </FormControl>
              </TableCell>
              <TableCell>
                <FormControl size="small" fullWidth>
                  <Select
                    value={ticket.status}
                    onChange={(e) => handleStatusChange(ticket.id, e.target.value)}
                    style={{ color: getStatusColor(ticket.status) }}
                  >
                    <MenuItem value="New" style={{ color: "blue" }}>New</MenuItem>
                    <MenuItem value="Open" style={{ color: "yellow" }}>Open</MenuItem>
                    <MenuItem value="Pending" style={{ color: "orange" }}>Pending</MenuItem>
                    <MenuItem value="Closed" style={{ color: "green" }}>Closed</MenuItem>
                  </Select>
                </FormControl>
              </TableCell>
              <TableCell>
                <IconButton onClick={(e) => handleClickMenu(e, ticket)}>
                  <MoreVertIcon />
                </IconButton>
                <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleCloseMenu}>
                  <MenuItem onClick={handleOpenEditModal}>
                    <EditIcon /> Edit
                  </MenuItem>
                  <MenuItem onClick={()=>handleDelete(ticket.id)}>
                    <DeleteIcon /> Delete
                  </MenuItem>
                </Menu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      {/* Edit Ticket Modal */}
      <Modal
        open={openEditModal}
        onClose={handleCloseEditModal}
        aria-labelledby="edit-ticket-modal"
        aria-describedby="edit-ticket-description"
      >
        <Box
          className="flex justify-center items-center"
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: '100vh', // Ensures full viewport height for vertical centering
          }}
        >
          <EditTicketForm
            ticket={selectedTicket}  // Pass the selectedTicket to the modal
            onClose={handleCloseEditModal}
            onSave={handleSaveTicket}
          />
        </Box>
      </Modal>

    </TableContainer>
  );
};

export default TicketTable;
