import TicketDetails from "./components/TicketDetails";

const TicketView=()=>{
    return(
        <>
            <TicketDetails/>
        </>
    )
}
export default TicketView;